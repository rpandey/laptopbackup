import RecipesList from './RecipesList';
import React from 'react';
import {render, screen, fireEvent} from '@testing-library/react';
import fakeData from './constants';

function setupFetchStub(data) {
    return function fetchStub() {
        return new Promise((resolve) => {
            resolve({
                json: () =>
                    Promise.resolve({
                        data,
                    }),
            });
        });
    };
}
describe('RecipesList', () => {
    beforeAll(() => {
        // const fakeData = {fake: 'data'};
        global.fetch = jest.fn().mockImplementation(setupFetchStub(fakeData));
    });
    afterAll(() => {
        delete global.fetch;
    });
  describe('Recipes', () => {
    it('should return the recipes', async () => {
        render(<RecipesList />);
        await new Promise((resolve) => setTimeout(resolve, 2000));

        expect(screen.getByTestId('selected-item-5f4d4aa9f4508b34e9680613').textContent).toBe('1 in your box');

        const test = screen.getByTestId('item-added-5f4d4aa9f4508b34e9680613');
        fireEvent.click(test);

        expect(screen.getByTestId('selected-item-5f4d4aa9f4508b34e9680613').textContent).toBe('2 in your box');

        const test1 = screen.getByTestId('item-removed-5f4d4aa9f4508b34e9680613');
        fireEvent.click(test1);

        expect(screen.getByTestId('selected-item-5f4d4aa9f4508b34e9680613').textContent).toBe('1 in your box');

    });
  });
});
